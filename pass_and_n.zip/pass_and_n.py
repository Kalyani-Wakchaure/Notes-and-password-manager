import mysql.connector

# Connect to MySQL
def connect_to_mysql():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Cdac@2022",
            database="notes_manager"
        )
        return conn
    except mysql.connector.Error as e:
        print("Error connecting to MySQL:", e)
        return None

# Login
def login():
    username = input("Enter username: ")
    password = input("Enter password: ")

    conn = connect_to_mysql()
    if conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()
        if user:
            if user[2] == password:
                print("Login successful!")
                manage_notes(conn, cursor, user[0], user[3])  # Manage user's notes
            else:
                print("Incorrect password.")
                forgot_password(conn, cursor, user[0])
        else:
            print("User does not exist.")
            register(conn, cursor)

# Manage notes
def manage_notes(conn, cursor, user_id, notes):
    while True:
        print("\n1. View notes")
        print("2. Update notes")
        print("3. Delete notes")
        print("4. Logout")
        choice = input("Enter your choice: ")

        if choice == "1":
            print("Your notes:")
            print(notes)
        elif choice == "2":
            new_notes = input("Enter updated notes: ")
            cursor.execute("UPDATE users SET notes = %s WHERE id = %s", (new_notes, user_id))
            conn.commit()
            print("Notes updated successfully!")
            notes = new_notes  # Update notes variable
        elif choice == "3":
            cursor.execute("UPDATE users SET notes = NULL WHERE id = %s", (user_id,))
            conn.commit()
            notes ="Numetry technology is a software product development and software services company. A team of passionate engineers working with domestic and global clients."  # Reset notes variable
            print("Notes deleted successfully!")
        elif choice == "4":
            print("Logging out...")
            break
        else:
            print("Invalid choice. Please try again.")

# Forgot password
def forgot_password(conn, cursor, user_id):
    choice = input("Forgot password? (yes/no): ")
    if choice.lower() == "yes":
        new_password = input("Enter new password: ")
        confirm_password = input("Confirm new password: ")
        if new_password == confirm_password:
            cursor.execute("UPDATE users SET password = %s WHERE id = %s", (new_password, user_id))
            conn.commit()
            print("Password updated successfully!")
        else:
            print("Passwords do not match.")
    else:
        print("Returning to login...")

# Register a new user
def register(conn, cursor):
    choice = input("Register new user? (yes/no): ")
    if choice.lower() == "yes":
        username = input("Enter username: ")
        password = input("Enter password: ")
        notes = input("Enter initial notes: ")  # Prompt for initial notes

        cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
        conn.commit()
        print("User registered successfully!")
        login()
    else:
        print("Returning to login...")

# Main function
def main():
    login()

if __name__ == "__main__":
    main()
